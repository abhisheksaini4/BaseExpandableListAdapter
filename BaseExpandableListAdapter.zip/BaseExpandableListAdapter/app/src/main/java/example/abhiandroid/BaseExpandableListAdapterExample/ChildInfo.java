package example.abhiandroid.BaseExpandableListAdapterExample;

public class ChildInfo {

    private String playerName = "";

    public String getName() {
        return playerName;
    }

    public void setName(String playerName) {
        this.playerName = playerName;
    }

}